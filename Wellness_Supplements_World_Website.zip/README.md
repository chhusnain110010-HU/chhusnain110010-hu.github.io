# Wellness & Supplements World — Website

A premium static e-commerce storefront for **Wellness & Supplements World**.

## Included
- Responsive premium homepage
- Brand sections: NOW Foods, Life Extension, Nature's Bounty
- Health & Wellness categories
- Product cards with official-brand product images/links
- Search and brand/category filters
- Shopping cart
- WhatsApp checkout
- Lahore: COD or Bank Transfer
- Other cities: advance Bank Transfer only
- Contact form routed to WhatsApp
- Mobile-first responsive design

## Important before going live
1. Replace the placeholder/local pricing logic with your actual PKR selling prices.
2. Add your bank name, account title and IBAN in the checkout/payment section.
3. Confirm product stock and Pakistan delivery charges before accepting an order.
4. The product image URLs currently point to official brand-hosted assets. For a production deployment, download/use brand-approved assets or obtain permission for commercial use rather than assuming image-hosting rights.
5. The official reference prices shown on some cards are U.S. brand-site reference prices and are NOT Pakistan selling prices.
6. For a real online payment gateway, connect a Pakistan-supported payment provider separately.

## Official product sources used for the initial catalog
NOW Foods: https://www.nowfoods.com/
Life Extension: https://www.lifeextension.com/
Nature's Bounty: https://naturesbounty.com/

WhatsApp: +92 301 0565675
