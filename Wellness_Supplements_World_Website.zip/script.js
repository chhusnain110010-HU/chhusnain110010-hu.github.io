const WA="923010565675";
const products=[
 {id:1,brand:"NOW Foods",name:"Vitamin D3 2,500 IU",size:"180 Softgels",category:"Vitamins",price:null,ref:"$8.99",img:"https://www.nowfoods.com/sites/default/files/styles/cloudzoom_image/public/2026-08/0356_v2.png?itok=CRE0rQmw",source:"https://www.nowfoods.com/products/supplements/vitamin-d3-2500-iu-softgels"},
 {id:2,brand:"NOW Foods",name:"Vitamin D3 5,000 IU",size:"120 Softgels",category:"Vitamins",price:null,ref:"$10.39",img:"https://www.nowfoods.com/sites/default/files/styles/cloudzoom_image/public/2025-09/0372_v14.png?itok=kMoFcEQm",source:"https://www.nowfoods.com/products/supplements/vitamin-d3-5000-iu-softgels"},
 {id:3,brand:"Life Extension",name:"Vitamin D3 5,000 IU",size:"60 Softgels",category:"Vitamins",price:null,ref:"$7.50",img:"https://www.lifeextension.com/-/media/lifeextension/products/large/01713.png?h=400&hash=64490A8BDBD56752656D56AB13D7FBBE&la=en&rev=6cedc5e5f6a34a1bb45107ad1af87533",source:"https://www.lifeextension.com/vitamins-supplements/item01713/vitamin-d3"},
 {id:4,brand:"Life Extension",name:"Super Omega-3 EPA/DHA",size:"120 Softgels",category:"Heart & Omega",price:null,ref:"$29.25",img:"https://www.lifeextension.com/-/media/lifeextension/products/large/01982.png?h=400&hash=31372C8DA300878C7CC47BA404179EBD&la=en&rev=e7926212fbce413d9a576fcfb1c89445",source:"https://www.lifeextension.com/vitamins-supplements/item01982/super-omega-3-epa-dha-fish-oil-sesame-lignans-olive-extract"},
 {id:5,brand:"Nature's Bounty",name:"Magnesium Gummies",size:"270 mg • 90 Gummies",category:"Minerals",price:null,ref:"Check WhatsApp",img:"https://naturesbounty.com/cdn/shop/products/L032499-NB-00A-RDGst-F.png?v=1682352045&width=750",source:"https://naturesbounty.com/products/magnesium-gummies"},
 {id:6,brand:"Nature's Bounty",name:"Magnesium 400 mg",size:"75 Softgels",category:"Minerals",price:null,ref:"Check WhatsApp",img:"https://naturesbounty.com/cdn/shop/products/059408.png?v=1667506680&width=750",source:"https://naturesbounty.com/products/magnesium-400mg-75-rapid-release-softgels"}
];
let cart=[];
const grid=document.getElementById("productGrid");
const count=document.getElementById("cartCount");
const cartDrawer=document.getElementById("cartDrawer");
const backdrop=document.getElementById("backdrop");

function renderProducts(list=products){
 grid.innerHTML=list.map(p=>`
 <article class="product-card">
   <div class="product-img"><img src="${p.img}" alt="${p.brand} ${p.name}" onerror="this.style.display='none'"></div>
   <div class="product-info">
     <span class="tag">${p.brand.toUpperCase()}</span>
     <h3>${p.name}</h3><p>${p.size}</p>
     <div class="price-row"><span class="price ${p.price===null?'muted':''}">${p.price?`PKR ${p.price.toLocaleString()}`:`${p.ref} reference • WhatsApp price`}</span>
     <button class="add-btn" onclick="addToCart(${p.id})">Add</button></div>
     <a class="source" href="${p.source}" target="_blank" rel="noopener">View official product ↗</a>
   </div>
 </article>`).join("");
}
function addToCart(id){const item=cart.find(x=>x.id===id); if(item)item.qty++; else cart.push({id,qty:1}); renderCart(); openCart();}
function renderCart(){
 count.textContent=cart.reduce((a,b)=>a+b.qty,0);
 const box=document.getElementById("cartItems");
 if(!cart.length){box.innerHTML='<p style="color:#748078;font-size:13px;padding:30px 0">Your cart is empty. Add a product to start your order.</p>';document.getElementById("cartTotal").textContent="PKR 0";return;}
 box.innerHTML=cart.map(x=>{const p=products.find(p=>p.id===x.id);return `<div class="cart-item"><img src="${p.img}" alt=""><div><h4>${p.name}</h4><small>${p.brand} • ${p.size}</small><div class="qty"><button onclick="changeQty(${p.id},-1)">−</button><span>${x.qty}</span><button onclick="changeQty(${p.id},1)">+</button></div></div><button class="icon-btn" onclick="removeItem(${p.id})">×</button></div>`}).join("");
 document.getElementById("cartTotal").textContent="Price confirmed on WhatsApp";
}
function changeQty(id,d){const x=cart.find(x=>x.id===id);if(!x)return;x.qty+=d;if(x.qty<=0)cart=cart.filter(x=>x.id!==id);renderCart();}
function removeItem(id){cart=cart.filter(x=>x.id!==id);renderCart();}
function openCart(){cartDrawer.classList.add("open");backdrop.classList.add("open")}
function closeCart(){cartDrawer.classList.remove("open");backdrop.classList.remove("open")}
document.getElementById("cartBtn").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
backdrop.onclick=closeCart;
document.getElementById("checkoutBtn").onclick=()=>{if(!cart.length){alert("Please add a product first.");return;}document.getElementById("checkoutModal").hidden=false;};
document.getElementById("closeCheckout").onclick=()=>document.getElementById("checkoutModal").hidden=true;

document.querySelectorAll(".filter").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.filter==="All"?products:products.filter(p=>p.brand===btn.dataset.filter));});
document.querySelectorAll(".brand-tile").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));document.querySelector('[data-filter="'+btn.dataset.brand+'"]')?.classList.add("active");renderProducts(products.filter(p=>p.brand===btn.dataset.brand));document.getElementById("products").scrollIntoView();});
document.querySelectorAll(".category-grid button").forEach(btn=>btn.onclick=()=>{renderProducts(products.filter(p=>p.category===btn.dataset.category));document.getElementById("products").scrollIntoView();});

const cityInput=document.getElementById("cityInput"), notice=document.getElementById("paymentNotice");
function updatePayment(){const lahore=/lahore/i.test(cityInput.value);const cod=document.querySelector('input[value="COD"]');cod.disabled=!lahore;if(!lahore){document.querySelector('input[value="Bank Transfer"]').checked=true;notice.textContent="For cities outside Lahore, Home Delivery requires advance Bank Transfer."}else notice.textContent="Lahore customers can choose Cash on Delivery or Bank Transfer."}
cityInput.addEventListener("input",updatePayment);

document.getElementById("checkoutForm").onsubmit=e=>{
 e.preventDefault();updatePayment();
 const fd=new FormData(e.target);const items=cart.map(x=>{const p=products.find(p=>p.id===x.id);return `${p.name} (${p.size}) × ${x.qty}`}).join("%0A");
 const msg=`Hello Wellness & Supplements World,%0A%0AI would like to place an order:%0A${items}%0A%0AName: ${encodeURIComponent(fd.get("name"))}%0AMobile: ${encodeURIComponent(fd.get("phone"))}%0AAddress: ${encodeURIComponent(fd.get("address"))}%0ACity: ${encodeURIComponent(fd.get("city"))}%0APayment: ${encodeURIComponent(fd.get("payment"))}%0A%0APlease confirm stock, final price and delivery charges.`;
 window.open(`https://wa.me/${WA}?text=${msg}`,"_blank");
};

document.getElementById("contactForm").onsubmit=e=>{e.preventDefault();const fd=new FormData(e.target);const msg=`Hello Wellness & Supplements World,%0A%0AName: ${encodeURIComponent(fd.get("name"))}%0AMobile: ${encodeURIComponent(fd.get("phone"))}%0A%0A${encodeURIComponent(fd.get("message"))}`;window.open(`https://wa.me/${WA}?text=${msg}`,"_blank");};

const searchOverlay=document.getElementById("searchOverlay"),searchInput=document.getElementById("searchInput");
document.getElementById("searchBtn").onclick=()=>{searchOverlay.hidden=false;searchInput.focus()};
document.getElementById("closeSearch").onclick=()=>searchOverlay.hidden=true;
searchInput.oninput=()=>{const q=searchInput.value.toLowerCase().trim();renderProducts(!q?products:products.filter(p=>(p.name+" "+p.brand+" "+p.category).toLowerCase().includes(q)));};
document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("open");
renderProducts();renderCart();
